#include <stdio.h>
#include <stdlib.h>

void main(){

	printf("------2017038042  ������------\n\n");

	int **x;

	printf("sizeof(x) = %lu\n", sizeof(x));
	printf("sizeof(*x) = %lu\n", sizeof(*x));
	printf("sizeof(**x) = %lu\n", sizeof(**x));
}
